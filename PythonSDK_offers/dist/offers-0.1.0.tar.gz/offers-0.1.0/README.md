pip install poetry
poetry install

Python: Select Interpreter  # insert path to poetry env

PS C:\Projects\PythonSDK_offers> poetry env info --path
C:\Users\radek\AppData\Local\pypoetry\Cache\virtualenvs\offers-riMDfWzY-py3.13


pytest