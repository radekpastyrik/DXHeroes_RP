import asyncio
import random
import time
from typing import Any, Callable, List, Optional, Type, TypeVar, Union
from functools import wraps
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

F = TypeVar('F', bound=Callable[..., Any])


@dataclass
class RetryConfig:
    """Konfigurace pro retry mechanismus"""
    
    max_attempts: int = 3
    """Maximální počet pokusů (včetně prvního)"""
    
    base_delay: float = 1.0
    """Základní zpoždění v sekundách"""
    
    max_delay: float = 60.0
    """Maximální zpoždění v sekundách"""
    
    exponential_base: float = 2.0
    """Základ pro exponenciální backoff"""
    
    jitter: bool = True
    """Přidat náhodný jitter pro prevenci thundering herd"""
    
    retryable_status_codes: List[int] = None
    """HTTP status kódy, které by měly být retryovány"""
    
    retryable_exceptions: List[Type[Exception]] = None
    """Typy výjimek, které by měly být retryovány"""
    
    def __post_init__(self):
        if self.retryable_status_codes is None:
            self.retryable_status_codes = [
                500,  # Internal Server Error
                502,  # Bad Gateway
                503,  # Service Unavailable
                504,  # Gateway Timeout
                429,  # Too Many Requests
            ]
        
        if self.retryable_exceptions is None:
            self.retryable_exceptions = [
                ConnectionError,
                TimeoutError,
                # Další výjimky budou přidány podle HTTP klienta
            ]
    
    def get_delay(self, attempt: int) -> float:
        """Vypočítá zpoždění pro daný pokus"""
        if attempt <= 0:
            return 0
        
        # Exponenciální backoff
        delay = self.base_delay * (self.exponential_base ** (attempt - 1))
        delay = min(delay, self.max_delay)
        
        # Přidat jitter pro prevenci thundering herd
        if self.jitter:
            jitter_range = delay * 0.1  # ±10% jitter
            delay += random.uniform(-jitter_range, jitter_range)
        
        return max(0, delay)


class RetryableError(Exception):
    """Výjimka označující, že operace by měla být retryována"""
    pass


def with_retry(config: Optional[RetryConfig] = None):
    """
    Dekorátor pro přidání retry logiky k async funkcím
    
    Args:
        config: Konfigurace retry mechanismus. Pokud None, použije se výchozí.
    """
    if config is None:
        config = RetryConfig()
    
    def decorator(func: F) -> F:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(1, config.max_attempts + 1):
                try:
                    return await func(*args, **kwargs)
                
                except Exception as e:
                    last_exception = e
                    
                    # Zkontrolovat, jestli by měl být error retryován
                    if not _should_retry(e, config):
                        logger.debug(f"Error not retryable: {type(e).__name__}: {e}")
                        raise
                    
                    # Pokud je to poslední pokus, vyhodit error
                    if attempt == config.max_attempts:
                        logger.warning(
                            f"Max retry attempts ({config.max_attempts}) reached for {func.__name__}"
                        )
                        raise
                    
                    # Vypočítat delay a čekat
                    delay = config.get_delay(attempt)
                    logger.info(
                        f"Retry attempt {attempt}/{config.max_attempts} for {func.__name__} "
                        f"after {delay:.2f}s. Error: {type(e).__name__}: {e}"
                    )
                    
                    await asyncio.sleep(delay)
            
            # Fallback (nemělo by se dostat sem)
            if last_exception:
                raise last_exception
        
        return wrapper
    return decorator


def _should_retry(exception: Exception, config: RetryConfig) -> bool:
    """Určí, jestli má být exception retryována"""
    
    # Zkontrolovat typ výjimky
    for exc_type in config.retryable_exceptions:
        if isinstance(exception, exc_type):
            return True
    
    # Zkontrolovat status kód, pokud má výjimka tento atribut
    if hasattr(exception, 'status_code'):
        return exception.status_code in config.retryable_status_codes
    
    # Zkontrolovat RetryableError
    if isinstance(exception, RetryableError):
        return True
    
    return False


def make_retryable_http_error(status_code: int, detail: str) -> Exception:
    """
    Vytvoří retryable HTTP error na základě status kódu
    
    Args:
        status_code: HTTP status kód
        detail: Detail chyby
        
    Returns:
        RetryableError pokud by měl být status kód retryován, jinak Exception
    """
    default_config = RetryConfig()
    
    if status_code in default_config.retryable_status_codes:
        return RetryableError(f"HTTP {status_code}: {detail}")
    
    return Exception(f"HTTP {status_code}: {detail}")


# Předkonfigurované retry konfigurace pro různé použití

# Agresivní retry pro kritické operace
AGGRESSIVE_RETRY = RetryConfig(
    max_attempts=5,
    base_delay=0.5,
    max_delay=30.0,
    exponential_base=2.0,
    jitter=True
)

# Konzervativní retry pro běžné operace
CONSERVATIVE_RETRY = RetryConfig(
    max_attempts=3,
    base_delay=1.0,
    max_delay=60.0,
    exponential_base=2.0,
    jitter=True
)

# Rychlý retry pro operace s malou latencí
FAST_RETRY = RetryConfig(
    max_attempts=3,
    base_delay=0.1,
    max_delay=5.0,
    exponential_base=1.5,
    jitter=True
) 